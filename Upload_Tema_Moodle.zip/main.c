#include <stdlib.h>
#include <string.h>


int main() {
	/// PAS 1
	// Read from "Pas_1/candidati.csv"
	// Write to "Pas_1/test_1.csv"
	
	return 0;
}
